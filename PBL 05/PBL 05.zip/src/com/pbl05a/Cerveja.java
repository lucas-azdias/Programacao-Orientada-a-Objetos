package com.pbl05a;

public class Cerveja extends Bebida {
	
	public Cerveja(String nomeFabricante, double precoUnitario, int quantidade) {
		super(nomeFabricante, precoUnitario, quantidade);
	}

}
