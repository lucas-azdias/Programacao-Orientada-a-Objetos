package Transportadora;

public enum Combustivel {

	DIESEL,
	GASOLINA,
	ALCOOL;

}
