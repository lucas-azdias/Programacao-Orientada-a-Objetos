package Transportadora;

public enum StatusVeiculo {
	
	IS_IN_REVISAO_TIME,
	IS_AVAILABLE,
	IS_BEING_USE;
	
}
