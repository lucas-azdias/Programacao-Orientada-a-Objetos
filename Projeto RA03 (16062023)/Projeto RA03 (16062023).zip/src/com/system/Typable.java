package com.system;

public interface Typable {
	
	public String type();
	
	public String typeToString();

}
