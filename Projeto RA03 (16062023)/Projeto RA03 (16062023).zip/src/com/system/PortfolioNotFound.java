package com.system;

public class PortfolioNotFound extends Exception {

	private static final long serialVersionUID = -2293785636399034426L;

}
